import tensorflow as tf
import requests
import json
from os import listdir, getenv
from os.path import isfile, join, isdir

serving_url = 'http://serving-app:5000'

def save_model(model, model_name, model_version='1.0.0', tf_version='1'):
    """ Save model """
    print('=== save_model ===')
    model_path = "./models/model-" + model_name + "-" + model_version + "/" + tf_version + "/"
    tf.saved_model.save(model, model_path)

def list_models():
    model_path = "./models/"
    models = []
    if isdir(model_path):
        model_dirs = [f for f in listdir(model_path) if not isfile(join(model_path, f))]
        for md in model_dirs:
            md_parts = md.split('-')
            if md_parts[0] and md_parts[0] == 'model':
                models.append({ 'model_name': md_parts[1], 'model_version': md_parts[2] })
    return models

def list_deployments():
    user = getenv('JUPYTERHUB_USER')
    resp = requests.get(serving_url + '/api/v1/containers?user=' + user)
    return resp.json()

def deploy_model(model_name, model_version='1.0.0'):
    user = getenv('JUPYTERHUB_USER')
    resp = requests.post(serving_url + '/api/v1/containers',
        json={'model_name': model_name, 'model_version': model_version, 'user': user},
        headers={'Content-type': 'application/json'})
    return resp.json()

def stop_deployment(model_name, model_version='1.0.0'):
    user = getenv('JUPYTERHUB_USER')
    resp = requests.delete(serving_url + '/api/v1/containers',
        json={'model_name': model_name, 'model_version': model_version, 'user': user},
        headers={'Content-type': 'application/json'})
    return resp.json()

def models_status():
    pass

def test_prediction(in_data, model_name, model_version='1.0.0'):
    serving_url = 'http://serving-app-proxy:3002/v1/models/predict?' + 'model=' + model_name + '&version=' + model_version
    resp = requests.post(serving_url,
                         data=json.dumps({"instances": in_data}),
                         headers={'Content-type': 'application/json'})
    data = resp.json()
    return data

def test_minst_air(in_air_data, model_name='mnist_air', nr_inputs=130):
    user = getenv('JUPYTERHUB_USER')
    serving_host = 'serving-app-proxy'
    serving_url = 'http://' + serving_host + ':3002/v1/models/predict?' + 'model=' + model_name + '&nr_inputs=' + str(nr_inputs) + '&user=' + user

    in_air_data_len = len(in_air_data)
    app_data3 = {"requestId":"DATA_PREDICTION", "data":{"points":[]}, "created":"2019-11-12T18:51:26.000Z"}

    i = 0
    while in_air_data_len > i:
        app_data3['data']['points'].append({'x': in_air_data[i], 'y': in_air_data[i+1], 'z': in_air_data[i+2]})
        i += 3

    resp = requests.post(serving_url,
                         data=json.dumps(app_data3),
                         headers={'Content-type': 'application/json'})
    data = resp.json()
    return data
