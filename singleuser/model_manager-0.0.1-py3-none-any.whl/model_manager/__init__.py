import tensorflow as tf
import requests
import json
from os import listdir, getenv
from os.path import isfile, join, isdir

serving_url = 'http://serving-app:5000'

def save_model(model, model_name, model_version='1.0.0', tf_version='1'):
    """ Save model """
    print('=== save_model ===')
    model_path = "./models/model-" + model_name + "-" + model_version + "/" + tf_version + "/"
    tf.saved_model.save(model, model_path)

def list_models():
    model_path = "./models/"
    models = []
    if isdir(model_path):
        model_dirs = [f for f in listdir(model_path) if not isfile(join(model_path, f))]
        for md in model_dirs:
            md_parts = md.split('-')
            if md_parts[0] and md_parts[0] == 'model':
                models.append({ 'model_name': md_parts[1], 'model_version': md_parts[2] })
    return models

def list_deployments():
    resp = requests.get(serving_url + '/api/v1/containers')
    return resp.json()

def deploy_model(model_name, model_version='1.0.0'):
    user = getenv('JUPYTERHUB_USER')
    print(user)
    resp = requests.post(serving_url + '/api/v1/containers',
        json={'model_name': model_name, 'model_version': model_version, 'user': user},
        headers={'Content-type': 'application/json'})
    return resp.json()

def stop_deployment(model_name, model_version='1.0.0'):
    resp = requests.delete(serving_url + '/api/v1/containers',
        json={'model_name': model_name, 'model_version': model_version},
        headers={'Content-type': 'application/json'})
    return resp.json()

def models_status():
    pass

def predict(in_data, model_name, model_version='1.0.0'):
    serving_url = 'http://serving-app-proxy:3002/v1/models/predict?' + 'model=' + model_name + '&version=' + model_version
    resp = requests.post(serving_url,
                         data=json.dumps({"instances": in_data}),
                         headers={'Content-type': 'application/json'})
    data = resp.json()
    return data
